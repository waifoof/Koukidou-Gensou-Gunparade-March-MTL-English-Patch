Translation source for the Gunparade March MTL English Patch.

translation/ev/   story event scripts (EVxxxx.txt): Japanese line, then "> English"
translation/ck/   menus, conversations, proposals, NPC chatter, battle text
translation/      map labels, prologue, names, glossary
en60_comparison/  comparison with Asterhex's GPM-EN60 build
